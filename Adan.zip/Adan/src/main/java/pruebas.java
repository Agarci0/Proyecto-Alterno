class Temperature {
    public String ciudad;
    public int min;
    public int max;

    // Constructor vacío para serialización JSON
    public Temperature() {}

    public Temperature(String ciudad, int min, int max) {
        this.ciudad = ciudad;
        this.min = min;
        this.max = max;
    }
}

