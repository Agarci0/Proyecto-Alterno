import lombok.Data;
@Data
public abstract class Duck {
    public Duck() {

    }
    public abstract void display();
@Override
public String toString() {
    return "this is a Duck";
    }
}