public class gameMain {
    public static void main(String[] args) {
        Arma espada = new Espada();
        Arma arcoYFlecha = new ArcoYFlecha();
        Arma hacha = new Hacha();
        Arma cuchillo = new Cuchillo();

        Personaje rey = new Rey(espada);
        Personaje reina = new Reina(arcoYFlecha);
        Personaje caballero = new Caballero(hacha);
        Personaje gnomo = new Gnomo(cuchillo);

        System.out.println(rey.getTipoPersonaje() + " ataca con poder: " + rey.atacar());
        System.out.println(reina.getTipoPersonaje() + " ataca con poder: " + reina.atacar());
        System.out.println(caballero.getTipoPersonaje() + " ataca con poder: " + caballero.atacar());
        System.out.println(gnomo.getTipoPersonaje() + " ataca con poder: " + gnomo.atacar());

        rey.cambiarArma(arcoYFlecha);
        reina.cambiarArma(hacha);
        caballero.cambiarArma(cuchillo);
        gnomo.cambiarArma(espada);

        System.out.println("\nDespués de cambiar de armas:");
        System.out.println(rey.getTipoPersonaje() + " ataca con poder: " + rey.atacar());
        System.out.println(reina.getTipoPersonaje() + " ataca con poder: " + reina.atacar());
        System.out.println(caballero.getTipoPersonaje() + " ataca con poder: " + caballero.atacar());
        System.out.println(gnomo.getTipoPersonaje() + " ataca con poder: " + gnomo.atacar());
    }
}

