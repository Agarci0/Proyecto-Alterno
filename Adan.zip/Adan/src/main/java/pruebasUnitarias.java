import org.testng.annotations.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
class ArmaTest {

    @Test
    void testEspadaAtacar() {
        Arma espada = new Espada();
        assertEquals(10, espada.atacar(), "El ataque de la espada debería ser 10");
    }
    private void assertEquals(int i, int atacar, String s) {
    }

    @Test
    void testArcoYFlechaAtacar() {
        Arma arcoYFlecha = new ArcoYFlecha();
        assertEquals(7, arcoYFlecha.atacar(), "El ataque del arco y flecha debería ser 7");
    }

    @Test
    void testHachaAtacar() {
        Arma hacha = new Hacha();
        assertEquals(8, hacha.atacar(), "El ataque del hacha debería ser 8");
    }

    @Test
    void testCuchilloAtacar() {
        Arma cuchillo = new Cuchillo();
        assertEquals(6, cuchillo.atacar(), "El ataque del cuchillo debería ser 6");
    }
}


