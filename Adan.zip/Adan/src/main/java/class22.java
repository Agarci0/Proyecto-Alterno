import java.awt.image.PixelGrabber;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

public class TemperatureResource {

    private static final Object MediaType =
    private Set<Temperature> temperaturas = new HashSet<>();

    public TemperatureResource(Temperature temperatura) {
        temperaturas.add(temperatura);
        AtomicReference<PixelGrabber> Response = null;
        return Response.get().status(Response.Status.CREATED).entity("Temperatura añadida correctamente").build();
    }

    public Set<Temperature> obtenerTemperaturas() {
        return temperaturas;
    }
}

