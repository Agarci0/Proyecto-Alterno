import org.junit.assert;
import org.junit.Test;

public class MoneyUtilTest {

    @Test
    public void moneyTest() {
        String money = moneyUtil.format(1000.0);
        assert.assertEquals("$1000.00", money);
    }

    private void assertEquals(String s, String money) {
    }

    @Test
    public void negativeMoneyTest() {
        String money = moneyUtil.format(-1000.0);
        assert.assertEquals("-$1000.00", money);
    }

    @Test
    public void euroMoneyTest() {
        String money = moneyUtil.format(-1000.0, "€");
        assert.assertEquals("-€1000.00", money);
    }

    @Test
            (expected = IllegalArgumentException.class)
    public void notNullExceptionMoneyTest() {
        moneyUtil.format(-1000.0, null);
    }

}